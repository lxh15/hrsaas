<template>
  <div class="dashboard-container">
    <div class="app-container">
      <h2>考勤</h2>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {}
  },

  created() {},

  methods: {}
}
</script>

<style scoped lang="less"></style>
